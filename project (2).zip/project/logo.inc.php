                <div class="logo">
                <img src="img/dez.jpg" alt="php">
                </div>  