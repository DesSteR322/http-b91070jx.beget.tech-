<div class="footer">

            <h2>Мы изучаем основы PHP!)</h2>

</div>