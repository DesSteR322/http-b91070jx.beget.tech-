            <nav>
                <ul>
                    <li><a href="#">About ma studios</a></li>
                    <li><a href="#">My protfolio </a></li>
                    <li><a href="#">My articles </a></li>
                    <li><a href="#">Links </a></li>
                    <li><a href="#">Contacts</a></li>
                </ul>
            </nav>